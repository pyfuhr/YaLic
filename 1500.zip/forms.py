from flask import Flask, render_template, url_for, redirect
from data import db_session
from data.jobs import Jobs


app = Flask(__name__)
app.config['SECRET_KEY'] = 'adlh5t0hnwn794vlh'


@app.route('/')
def main():
    session = db_session.create_session()
    j = session.query(Jobs).all()
    return render_template('jobs.html', jobs=j)


if __name__ == '__main__':
    db_session.global_init("db/blogs.db")
    app.run(port=8080, host='127.0.0.1')
