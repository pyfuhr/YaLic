from flask import Flask, render_template, url_for
import random

app = Flask(__name__)


@app.route('/<title>')
@app.route('/index/<title>')
def form_sample(title):
    if 'строитель' in title.lower() or 'инженер' in title.lower():
        ph = url_for('static', filename='sha_e.jpg')
        return render_template('ext.html', **{'title': title, 'spec': 'Инженера', 'photo': ph})
    else:
        ph = url_for('static', filename='sha_s.jpg')
        return render_template('ext.html', **{'title': title, 'spec': 'Другие(Ученые)', 'photo': ph})

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
